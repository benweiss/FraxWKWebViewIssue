// *********************************************************************************************************************
// TapDetectingWindow - implementation
// Copyright ©2010-2024 by Ben Weiss, Iter9 LLC
// *********************************************************************************************************************

#import "TapDetectingWindow.h"

@implementation TapDetectingWindow

@synthesize controllerThatObserves;

- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }

- (id)initWithViewToObserver:(UIView *)view andDelegate:(id)delegate {
  if(self = [super init]) {
    self.controllerThatObserves = delegate;
  }
  return self;
}

- (void)sendEvent:(UIEvent *)event {
  [super sendEvent:event];
  if (controllerThatObserves == nil)
    return;
  NSSet *touches = [event allTouches];
  
  // ____ if there are any touch events, send a message to observer whether they represent all touches ending
  if ([touches count] > 0) {
    //NSLog(@"tdWindow sendEvent with touches");
    BOOL anyTouchActive = NO;
    for (UITouch* touch in touches) {
      if (touch.phase == UITouchPhaseBegan || touch.phase == UITouchPhaseMoved || touch.phase == UITouchPhaseStationary) {
        anyTouchActive = YES;
      }
    }
    
    [controllerThatObserves setAnyTouchActive:anyTouchActive];
  }
}

@end
