// *********************************************************************************************************************
// TapDetectingWindow.h
//
// Copyright ©2010-2021 by Ben Weiss, Iter9 LLC
//
// Version: 2.0.1 - September 27th, 2020
// *********************************************************************************************************************

#import <UIKit/UIKit.h>

// ____ proper double-tap interception for webViews!!
@protocol TapDetectingWindowDelegate
-(void)setAnyTouchActive:(BOOL)anyTouchActive;
@end

// TapDetectingWindow - a UIWindow with hooks to properly intercept double-taps.
@interface TapDetectingWindow : UIWindow {
  id <TapDetectingWindowDelegate> __weak controllerThatObserves;
}
@property (nonatomic, weak) id <TapDetectingWindowDelegate> controllerThatObserves;
@end
