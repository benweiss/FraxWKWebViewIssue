// *************************************************************************************************
// FixedViewController - implementation
// Copyright ©2024 by Ben Weiss, Iter9 LLC
// *************************************************************************************************
#import "FixedViewController.h"

@implementation FixedViewController

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
  return UIInterfaceOrientationMaskPortrait;
}

- (BOOL)shouldAutorotate               { return YES; }
- (BOOL)prefersStatusBarHidden         { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }

@end
