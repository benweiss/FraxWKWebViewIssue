// *********************************************************************************************************************
// FraxViewController - implementation
// Copyright ©2010-2024 by Ben Weiss, Iter9 LLC
// *********************************************************************************************************************

#import "FraxViewController.h"

#import "CloudViewController.h"
#import "FraxAppDelegate.h"

@implementation BackgroundViewController

@synthesize fraxViewController;

- (BOOL)prefersStatusBarHidden         { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }

-(void)viewDidLoad {
  [super viewDidLoad];
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations {
  return UIInterfaceOrientationMaskAll;
}

- (UIInterfaceOrientationMask)navigationControllerSupportedInterfaceOrientations:(UINavigationController *)navigationController {
  return UIInterfaceOrientationMaskAll;
}

@end


@implementation FraxViewController

@synthesize popoverTarget=popoverTarget_;
@synthesize cloudPopoverActive;
@synthesize cloudViewController;
@synthesize cloudPopover;

- (BOOL)prefersStatusBarHidden {
  return YES;
}

- (BOOL)prefersHomeIndicatorAutoHidden {
  return YES;
}

- (void)setAnyTouchActive:(BOOL)ata {}

- (void)viewDidLoad {
  [super viewDidLoad];
  app = (FraxAppDelegate*)[[UIApplication sharedApplication] delegate];
  ipad = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad;
}

- (void)dealloc {}

- (void)navigationController:(UINavigationController *)navigationController
      willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {}
- (void)navigationController:(UINavigationController *)navigationController
       didShowViewController:(UIViewController *)viewController animated:(BOOL)animated{}

- (void)clickRenderTab:(id)sender {
  [self showCloudPopover];
  [cloudViewController showHiResUpgrade];
}

-(void)closeCloudClicked { [self dismissCloudPopover]; }

- (void)showCloudPopover {
  NSLog(@"Presenting Cloud Popover...");
  if (cloudPopoverActive) { NSLog(@"Cloud popover already active!!"); return; }
  
  cloudPopoverActive = YES;
  cloudViewController = [[CloudViewController alloc] initWithNibName:@"CloudView" bundle:nil];
    
  if (ipad) { // use popover
    cloudViewController.view.autoresizingMask = UIViewAutoresizingFlexibleTopMargin |
      UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin |
      UIViewAutoresizingFlexibleRightMargin;
    cloudViewController.preferredContentSize = cloudViewController.view.frame.size;
    CGRect frame = self.view.bounds;
    
    cloudPopover = cloudViewController;
    cloudPopover.modalPresentationStyle                   = UIModalPresentationPopover;
    cloudPopover.popoverPresentationController.sourceView = self.view;
    cloudPopover.popoverPresentationController.sourceRect = frame;
    cloudPopover.popoverPresentationController.permittedArrowDirections = 0;
    UIViewController* rvc = [app rootViewController];
    [rvc presentViewController:cloudPopover animated:YES completion:nil];
  } else {  // use full screen
    cloudViewController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth |
      UIViewAutoresizingFlexibleHeight;
    cloudViewController.view.frame = self.view.bounds;
    [self.view addSubview:cloudViewController.view];
  }

  [cloudViewController showSavePage];
  cloudViewController.view.hidden = NO;
}

- (void)dismissCloudPopover {
  if (ipad) {
    [cloudPopover dismissViewControllerAnimated:YES completion:nil];
    cloudPopover = nil;
  } else {
    [cloudViewController.view removeFromSuperview];
  }
  cloudPopoverActive = NO;
  cloudViewController = nil;
}

@end
