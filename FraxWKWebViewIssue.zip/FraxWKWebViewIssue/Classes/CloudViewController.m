// *********************************************************************************************************************
// CloudViewController - implementation
// Copyright ©2011-2021 by Ben Weiss, Iter9 LLC
// *********************************************************************************************************************

#import "CloudViewController.h"

#import <QuartzCore/QuartzCore.h>
#import <WebKit/WebKit.h>

#import "FraxViewController.h"
#import "FraxAppDelegate.h"

@implementation CloudViewController

@synthesize backdropView;
@synthesize webView;
@synthesize closeButton;

- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }

- (NSString *)stringByEvaluatingJavaScriptFromString:(NSString *)script {
  __block NSString *resultString = nil;
  __block BOOL finished = NO;
  [webView evaluateJavaScript:script completionHandler:^(id result, NSError *error) {
    if (error == nil) {
      if (result != nil) {
        resultString = [NSString stringWithFormat:@"%@", result];
      }
    } else {
      NSLog(@"evaluateJavaScript error : %@", error.localizedDescription);
    }
    finished = YES;
  }];
  while (!finished)
  {
    [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
  }
  return resultString;
}

// ____ Handles callbacks from webpage to app
- (void)webView:(WKWebView *)inWeb decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
  NSLog(@"WKWebView decidePolicyForNavigationAction");
  WKNavigationType inType = navigationAction.navigationType;
  NSURLRequest* request = navigationAction.request;
  NSLog(@"NavigationType: %ld", (long)inType);
  NSLog(@"request: %@", request);
  
  if ([[[request URL] absoluteString] hasPrefix:@"fraxhd://"]
      || [[[request URL] absoluteString] hasPrefix:@"fraxbeta://"]) {
    NSLog(@"Custom URL scheme: ignoring");
    decisionHandler(WKNavigationActionPolicyCancel);
    return;
  }
  
  if ( inType == UIWebViewNavigationTypeLinkClicked ) {
    NSLog(@"WKWebViewNavigationTypeLinkClicked");
    decisionHandler(WKNavigationActionPolicyAllow);
    return;
  }
  
  NSString *requestString = [[[request URL] absoluteString] stringByRemovingPercentEncoding];
  
  if ([requestString hasPrefix:@"ios-cmd:"]) {
    NSString* logString = [[requestString componentsSeparatedByString:@":#iOS#"] objectAtIndex:1];
    NSLog(@"CloudViewController WKWebView console: %@, %@", logString, requestString);
    if ([logString isEqualToString:@"proStatus"]) {
      NSString* script = [NSString stringWithFormat:@"proStatus(%i)", 0];
      NSLog(@"CloudViewController script: %@", script);
      __unused NSString *result = [self stringByEvaluatingJavaScriptFromString:script];
      NSLog(@"CloudViewController script result: %@", result);
      decisionHandler(WKNavigationActionPolicyCancel);
      return;
    }
    NSArray* components = [logString componentsSeparatedByString:@":"];
    if ([components count] == 1 && [[components objectAtIndex:0] isEqualToString:@"details"]) {
      NSLog(@"CloudViewController - details requested (name, comment, Pro status)");
      int proStatus = 0;
      NSString* name = @"";
      NSString* comment = @"";
      NSString* script = [NSString stringWithFormat:@"setDetails(\"%@\", \"%@\", %i)", name, comment, proStatus];
      NSLog(@"CloudViewController script: %@", script);
      __unused NSString *result = [self stringByEvaluatingJavaScriptFromString:script];
      NSLog(@"CloudViewController script result: %@", result);
    }
    NSLog(@"CloudViewController shouldStartLoadWithRequest completed, result = NO");
    decisionHandler(WKNavigationActionPolicyCancel);
    return;
  }
  NSLog(@"CloudViewController shouldStartLoadWithRequest completed, result = YES");
  decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)showSavePage {
  NSString *filePathString = [[NSBundle mainBundle] pathForResource:@"launch_page_save" ofType:@"html"];
  NSURL *srcURL = [NSURL fileURLWithPath:filePathString];
  [webView loadFileURL:srcURL allowingReadAccessToURL:srcURL];
}

- (void)showHiResUpgrade {
  NSString *filePathString = [[NSBundle mainBundle] pathForResource:@"launch_page_hires" ofType:@"html"];
  NSURL *aURL = [NSURL fileURLWithPath:filePathString];
  NSURLRequest *aRequest = [NSURLRequest requestWithURL:aURL];
  [webView loadRequest:aRequest];
}

- (IBAction)closeButtonClicked:(id)sender {
  FraxAppDelegate* app = (FraxAppDelegate*)[[UIApplication sharedApplication] delegate];
  [app.fraxViewController closeCloudClicked];
}

- (void)viewDidLoad {
  [super viewDidLoad];
  backdropView.center = self.view.center;
  webView.opaque = NO;
  webView.backgroundColor = [UIColor clearColor];
  webView.autoresizesSubviews = YES;
  webView.autoresizingMask=(UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth);
  [webView setUIDelegate:self];
  [webView setNavigationDelegate:self];
  
  // Sets preferred content mode to Mobile. (Fixes issue on iPad OS 15.6+ where
  // the desktop frax homepage would appear instead of the mobile cloud page.)
  webView.configuration.defaultWebpagePreferences.preferredContentMode = WKContentModeMobile;
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {}

- (void)webView:(WKWebView *)webView didFailLoadWithError:(NSError *)error {
  NSLog(@"CloudViewController - webView didFailLoadWithError! %@ %@", error, [error userInfo]);
}

@end
