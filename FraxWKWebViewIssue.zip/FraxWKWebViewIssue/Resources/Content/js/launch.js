var reloadInt = 0,
  host = 'fraxcloud.herokuapp.com',  // keep in sync with FraxAppDelegate.h
  timeout = 0,
  offline = function () {
    document.getElementById("content").className = "offline";
  },
  online = function () {
    document.getElementById("content").className = "";
    window.clearTimeout(timeout);
    timeout = window.setTimeout(function () {
      document.getElementById("content").className = "unavailable";
      window.location.href = "#";
    }, 10 * 1000);
    window.location.href = "https://" + host + path;
  },
  launch = function () {
    window.setTimeout(function () {
      window.addEventListener("online", online, false);
      window.addEventListener("offline", offline, false);
      
      if (navigator.onLine) {
        online();
      } else {
        offline();
      }
    }, 750);
  };

window.cmd = {};
cmd.exec = function(action) {
  console.log("ios-cmd:#iOS#" + action);
  // return false;
  var iframe = document.createElement("IFRAME");
  iframe.setAttribute("src", "ios-cmd:#iOS#" + action);
  document.documentElement.appendChild(iframe);
  iframe.parentNode.removeChild(iframe);
  iframe = null;
};

// Called from the app in response to 'ios-cmd:#iOS#proStatus'
window.proStatus = function(status) {
  if (parseInt(status, 10) == 1) {
    path += "?pro_status=1";
  }
  launch();
  return path;
};


window.onload = function () {
  // First get the app status, which then calls launch() with a modified URL
  window.cmd.exec('proStatus');
};
