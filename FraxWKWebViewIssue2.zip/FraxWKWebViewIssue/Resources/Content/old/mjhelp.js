
// window.console = {};
// console.log = function(log) {
// 	var iframe = document.createElement("IFRAME");
// 	iframe.setAttribute("src", "ios-log:#iOS#" + log);
// 	document.documentElement.appendChild(iframe);
// 	iframe.parentNode.removeChild(iframe);
// 	iframe = null;    
// }

window.cmd = {};
cmd.exec = function(action) {
	// console.log("ios-cmd:#iOS#" + action);
	// return false;
    var iframe = document.createElement("IFRAME");
    iframe.setAttribute("src", "ios-cmd:#iOS#" + action);
    document.documentElement.appendChild(iframe);
    iframe.parentNode.removeChild(iframe);
    iframe = null;
}

// document.addEventListener('touchmove', function(e){ e.preventDefault(); });

var pageIDs = {},
	tabIDs = {},
	buttonIDs = {},
	contentElms = {},
	currentPage = -1,
	helpIDIndex = {},
	pageWidth = window.screen.height <= 960 ? 310 : 720,
	totalWidth = 0,
	$panel,
	$activePage,
	$prevPage,
	$nextPage,
	down = "mousedown",
	up   = "mouseup",
	move = "mousemove",
	timeout = {},
	pages = 0,
	oldX = 0,
	$pageNum,
	$prev,
	$next,
	$nextLink,
	$title,
	titles = [],
	headers = [],
	scrollID = 0,
	fingers = 0,
	pageStart = 0,
	scrolling = false,
    allReady = false;


$(function () {
	
	
	/*
	var orientationChange = function () {
		if (Math.abs(window.orientation) == 90) {
			$("body").removeClass("orientation-alert");
		} else {
			$("body").addClass("orientation-alert");
		}
	};
	*/
	if (pageWidth <= 310) {
		$("body").addClass("iphone");
		$("h1 span").text("Help");
		// $(window).bind('orientationchange', orientationChange);
		// orientationChange();
	}
	
  window.setTimeout(function () {
    allReady = true;
    cmd.exec("helpready");
  }, 300);
  
});



// Called from Cocoa
function selectTab(left, right) {
    if (!allReady) {
        return false;
    }
	// Show second lights and textures using the first set of pages
	if (left == 4 || left == 7) left -= 1;
	var id = left + "-" + right;
	
	//alert("Left-right tabs: " + id);
	
	if (tabIDs[id]) {
		showPage(tabIDs[id]);
	} else {
		alert('Could not find page id: ' + id);
	}
    return id;
}



function showPage(id) {
	// alert(helpID[parseInt(id)] + ":" + id + "#page" + pageIDs[helpID[parseInt(id)]]);
	if (helpID[parseInt(id)]) {
        currentPage = pageIDs[helpID[parseInt(id)]];
		id = "#page" + currentPage;
	}

	id = id.replace("page", "page_");
	$activePage = $(id);
	$prevPage = $activePage.prev();
	$nextPage = $activePage.next();

	$activePage.css({left: '0px'});
	$prevPage.css({left: -pageWidth + 'px'});
	$nextPage.css({left: pageWidth + 'px'});
	updatePages(false);
}


function updatePages(sendCmd) {
	$(".page").removeClass("active prev next");
	$prevPage.addClass("prev");
	$nextPage.addClass("next");
	$activePage.addClass("active");

	var pid = parseInt($activePage.attr("id").match(/[\d]+/)[0])

	$title.html(headers[pid]);

	if ($nextPage.length > 0) {
		$nextLink.attr({href: "#" + $nextPage.attr("id").replace("_", "")}).html('<em>Next:</em> ' + titles[pid + 1]);
		$next.show();
	} else {
		$next.hide();
	}

	$pageNum.text((pid + 1) + " / " + pages).show();

	if (sendCmd) {
		cmd.exec("help:" + (buttonIDs[pid] || 0));
	}
}



function resetVideo(reset) {
	$("video").each(function (i, e) {
		e.pause();
		if (reset) e.currentTime = 0;
	});
}

function resetAll() {
	window.location.hash = "#page1";
	resetVideo();
}


function scrollTo(x, dy) {
	x = parseInt(x);
	dy = parseInt(dy);
	
	$panel[0].scrollLeft = x;
	
	if (dy != 0) {
		var page = Math.round(x / pageWidth) + 1;
		contentElms[page].scrollTop += dy;
	}
}


// shim layer with setTimeout fallback
window.requestAnimFrame = (function(){
  return  window.requestAnimationFrame       ||
          window.webkitRequestAnimationFrame ||
          window.mozRequestAnimationFrame    ||
          window.oRequestAnimationFrame      ||
          window.msRequestAnimationFrame     ||
          function( callback ){
            window.setTimeout(callback, 1000 / 60);
          };
})();

var main = function () {
	$panel = $("#panel");
	pages = $(".page").length;
	oldX = 0;
	$pageNum = $("#page_num");
	$prev = $("#prev");
	$next = $("#next");
	$nextLink = $("a", $next);
	$title = $(".title");
	totalWidth = pages * pageWidth;
	
	// General events
	if ('createTouch' in document) { 
		down = "touchstart"; 
		up   = "touchend touchcancel";
		move = "touchmove";
	}
	
	for (var i = 0; i < helpID.length; i++) {
		helpIDIndex[helpID[i]] = i;
	}
	
	$(".page").each(function (i, e) {
		var elm = $(this),
			help = elm.data('help'),
			tab = elm.data('tab'),
			header = elm.data('header'),
			title = $("h1", this).text() || header;
		
		titles.push(title);
		headers.push(header);
		
		if (help && !pageIDs[help]) {
			pageIDs[help] = i + pageStart;
			buttonIDs[pageIDs[help]] = helpIDIndex[help] || 0;
			var p = $("<p>").addClass("bullet").append($("<a>").attr({href:"#page" + pageIDs[help]}).text(title));
			$("#toc").append(p);
		}	
		
		if (tab && pageIDs[help]) {
			tabIDs[tab] = helpID.indexOf(help);
		}
		
		contentElms[i + pageStart] = $(".content", this)[0];
	});
	
	
	$(".videocontrols").bind(up, function (event) {
		if (scrolling) return false;

		$video = $(event.target).addClass("active").next();
		// console.log("vid", $video);
		if ($video[0]) {
			if ($video[0].paused) {
				$video[0].play();
			} else {
				$video[0].pause();
			}
		}
		return false;
	});
	
	$("a").bind(down, function (event) {
		if (scrolling) return false;

		var href = $(event.target).attr("href");
		if (href.indexOf("#") == 0) {
			showPage(href);
			return false;
		}
	});



	var positionPages = function (offset) {
		$activePage.css({left: offset + "px"});
		$prevPage.css({left: offset - pageWidth + "px"});
		$nextPage.css({left: offset + pageWidth + "px"});
	}

	$panel.bind(down, function (event) {
		if (scrolling || (event.touches && event.touches.length > 1)) {
			return false;
		}

		var x = event.pageX,
			x0 = x,
			tx = 0,
			dx = 0,
			av = [],
			intervalID,
			t0 = Date.now(),
			moveX = false,
			offset = 0,
			v = 0;
		

		$panel.bind(move, function (event) {
			tx = x0 - event.pageX;
			dx = (x - event.pageX) * 1.0;
			dt = Date.now() - t0;
			v = dx / dt;
			
			if (!moveX && Math.abs(tx) > 20) {
				moveX = true;
				scrolling = true;
				resetVideo();

			} else if (moveX) {
				offset -= dx;
				positionPages(offset);
			}
			
			x = event.pageX;
		});

		$panel.bind(up, function (event) {
			$panel.unbind(move).unbind(up);
			
			// Find target end position
			var tx, dx, px = parseInt($activePage.css("left")) / pageWidth;

			if (v > 0.1 || px < -0.25) {
				tx = Math.floor(px) * pageWidth;
				
			} else if (v < -0.1 || px > 0.25) {
				tx = Math.ceil(px) * pageWidth;
				
			} else {
				tx = Math.round(px) * pageWidth;
			}
			
			// Boundary check
			if ((tx == pageWidth && $prevPage.length == 0) || (tx == -pageWidth && $nextPage.length == 0)) {
				tx = 0;
			}

			// Move to target
			var scroller = function () {
				var px = parseInt($activePage.css("left")),
					ds = Math.max(Math.min((tx - px) * 0.3, 30), -30);

				if (Math.abs(ds) <= 1) {
					// Final position
					positionPages(tx);

					if (tx < 0) {
						// next page
						$activePage = $activePage.next();
						$prevPage = $activePage.prev();
						$nextPage = $activePage.next();
						updatePages(true);

					} else if (tx > 0) {
						// prev page
						$activePage = $activePage.prev();
						$prevPage = $activePage.prev();
						$nextPage = $activePage.next();
						updatePages(true);
					}

					scrolling = false;
					return false;
				} else {
					positionPages(px + ds);
				}
				
				// intervalID = window.setTimeout(scroller, 16);
				requestAnimFrame(scroller);
			};
			scroller();
		});


	});

	// Jump to a page based on the URL
	if (window.location.hash.match(/page[\d]+/)) {
		showPage(window.location.hash);
	}

	window.setTimeout(function () {
		if (!$activePage || $activePage.length == 0) {
			showPage("#page1");
		}
	}, 500);
}


$("body")[0].onload = function () {
	window.setTimeout(main, 50);
};

