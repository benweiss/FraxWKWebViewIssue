var reloadInt = 0,
//    host = 'cloud.fract.al',
    host = 'cloud.fract.al',
    offline = function () {
      document.getElementById("content").className = "offline";
    },
    online = function () {
      document.getElementById("content").className = "";
      window.location.href = "http://" + host + path;
    };

window.onload = function () {
  window.setTimeout(function () {
    window.addEventListener("online", online, false);
    window.addEventListener("offline", offline, false);
    
    if (navigator.onLine) {
      online();
    } else {
      offline();
    }
  }, 750);
};