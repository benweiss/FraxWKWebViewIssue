
// window.console = {};
// console.log = function(log) {
// 	var iframe = document.createElement("IFRAME");
// 	iframe.setAttribute("src", "ios-log:#iOS#" + log);
// 	document.documentElement.appendChild(iframe);
// 	iframe.parentNode.removeChild(iframe);
// 	iframe = null;    
// }

window.cmd = {};
cmd.exec = function(action) {
    var iframe = document.createElement("IFRAME");
    iframe.setAttribute("src", "ios-cmd:#iOS#" + action);
    document.documentElement.appendChild(iframe);
    iframe.parentNode.removeChild(iframe);
    iframe = null;
}


// Called from Cocoa
function showCategory(id) {
    console.log("Info html Show Category: " + id);
    
	if (!id) return;
	match = id.match(/#(\d+)/);
    
    var page = $(id);
    
    if (match) {
        if (match[1] == "0") {
            page = $("#about");
        }
        else if (match[1] == "1") {
            page = $("#faq");
        }
        else if (match[1] == "2") {
            page = $("#demo");
        }
        else if (match[1] == "3") {
            page = $("#tutorial");
        }
        else if (match[1] == "4") {
            // $("#prefSafeguards").attr("disabled", "1");
            $("#prefRememberMultidice").attr("disabled", "1");
            $("#prefAllowBackgroundMotion").attr("disabled", "1");
            $("#prefFirstStar").attr("disabled", "1");
            $("#prefIpadScaling").attr("disabled", "1");
            
            page = $("#prefs");
        }
        else {
            page = $("about"); // catch-all
        }
    }
	else {
        page = $("about"); // catch-all
    }
	
	$(".page.active").removeClass("active");
	window.scrollTo(0, 0);
	page.addClass("active");
     
}

function setPref(id, value) {
	var elm = $("#" + id),
		val = parseFloat(value);
	
	if (elm.length > 0) {
		// Found input element
		if (elm.attr("type") == "checkbox") {
			if (val == 1) {
				elm.attr("checked", "1");
			} else {
				elm.removeAttr("checked");
			}
		} else {
			elm.val(val);
			
			if (elm.attr("type") == "range") {
				showValue(id);
			}
		}
	}
}


// Update a display value for the sliders rounding to 2 d.p.
function showValue(id) {
	var val = parseFloat($("#" + id).val()).toFixed(2);
	$("#" + id + "_val").text(val);
}


$(document).ready(function () {
	var down = "mousedown",
		up = "mouseup",
		move = "mousemove",
		timeout = {};
	
	// General events
	if ('createTouch' in document) { 
		down = "touchstart"; 
		up   = "touchend";
		move = "touchmove";
	}
	
	$("#menu a").click(function (event) {
		return (event.target.href == "fraxflyer://close_info");
	});
	
	// Change 'page' panels when clicking the top menu
	$("#menu a").not(".close").bind(down, function (event) {
		var page = $($(event.currentTarget).attr("href"));
		$(".active").removeClass("active");
		$(event.currentTarget).addClass("active");
		page.addClass("active");
		window.location = event.target;
		// return false;
	});
	
	$.each($("input[type=range]"), function (idx, elm) {
		showValue(elm.id);
	});
	
	$("input[type=range]").change(function (event) {
		var pref = event.target.id + ":" + event.target.value;
		showValue(this.id);
		
		window.clearTimeout(timeout[event.target.id]);
		timeout[event.target.id] = window.setTimeout(function () {
			cmd.exec(pref);
		}, 750);
		
	});
	
	$("input[type=checkbox]").bind('touchstart', function (event) {
		event.target.checked = !event.target.checked;
		cmd.exec(event.target.id + ":" + event.target.checked);
		return false;
	});
	
	$("input[type=checkbox]").bind('click touchend', function (event) {
		return false;
	});
	
});