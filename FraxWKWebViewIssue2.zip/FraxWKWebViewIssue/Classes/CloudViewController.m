// *********************************************************************************************************************
// CloudViewController - implementation
// Copyright ©2011-2021 by Ben Weiss, Iter9 LLC
// *********************************************************************************************************************

#import "CloudViewController.h"

#import <QuartzCore/QuartzCore.h>
#import <WebKit/WebKit.h>

#import "FraxViewController.h"
#import "FraxAppDelegate.h"

@implementation CloudViewController

@synthesize backdropView;
@synthesize webView;
@synthesize closeButton;

- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }

- (NSString *)stringByEvaluatingJavaScriptFromString:(NSString *)script {
  __block NSString *resultString = nil;
  __block BOOL finished = NO;
  [webView evaluateJavaScript:script completionHandler:^(id result, NSError *error) {
    if (error == nil) {
      if (result != nil) {
        resultString = [NSString stringWithFormat:@"%@", result];
      }
    } else {
      NSLog(@"evaluateJavaScript error : %@", error.localizedDescription);
    }
    finished = YES;
  }];
  while (!finished)
  {
    [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
  }
  return resultString;
}

- (void)webView:(WKWebView *)webView startURLSchemeTask:(id<WKURLSchemeTask>)urlSchemeTask {
  NSLog(@"startURLSchemeTask: url = %@", urlSchemeTask.request.URL);
  
  // For some reason, 'lastPathComponent' doesn't work properly here?
  NSString* urlString = [urlSchemeTask.request.URL absoluteString];
  
  NSString* scheme = @"frax-localloader:";
  if (![urlString hasPrefix:scheme]) {
    NSLog(@"startURLSchemeTask: unexpected prefix! Returning.");
    return;
  }
  urlString = [urlString substringFromIndex:[scheme length]];
  NSLog(@"startURLSchemeTask: trimmed url = %@", urlString);
  /*
  NSArray<NSString*>* components = [urlString componentsSeparatedByString:@":"];
  if (components.count >= 3 && [components.firstObject isEqualToString:@"frax-localloader"] && [[components objectAtIndex:1] isEqualToString:@"https"])
  */
  
  NSURLResponse* response = nil;
  NSData* data = nil;
  /*
  if ([urlString hasPrefix:@"frax-localloader:http"]) {
  }
  
  NSString* type = [[urlString componentsSeparatedByString:@":"] lastObject];
  */
  
  if ([urlString isEqualToString:@"launch_js"]) {
    NSLog(@"startURLSchemeTask: Attempting to load launch.js from app bundle");
    NSURL *resourceURL = [[NSBundle mainBundle] URLForResource:@"js/launch" withExtension:@"js"];
    if (resourceURL) {
      data = [NSData dataWithContentsOfURL:resourceURL];
      if (data) {
        response = [[NSURLResponse alloc] initWithURL:resourceURL
                                             MIMEType:@"text/javascript"
                                expectedContentLength:data.length
                                     textEncodingName:nil];
      } else {
        NSLog(@"startURLSchemeTask: Unable to extract data from bundle URL");
      }
    } else {
      NSLog(@"startURLSchemeTask: resourceURL not initialized!");
    }
  } else if ([urlString hasPrefix:@"https"]) {
    NSLog(@"startURLSchemeTask: Attempting to load remote https content");
    NSURL* resourceURL = [NSURL URLWithString:urlString];
    data = [NSData dataWithContentsOfURL:resourceURL];
    if (data) {
      response = [[NSURLResponse alloc] initWithURL:resourceURL
                                           MIMEType:@"text/html"
                              expectedContentLength:data.length
                                   textEncodingName:nil];
    } else {
      NSLog(@"startURLSchemeTask: Unable to extract data from remote URL");
    }
  }
  
  if (response && data) {
    NSLog(@"startURLSchemeTask: Successfully received response and data");
    NSLog(@"startURLSchemeTask: response = %@", response);
    NSLog(@"startURLSchemeTask: data = %@", data);
    [urlSchemeTask didReceiveResponse:response];
    [urlSchemeTask didReceiveData:data];
    [urlSchemeTask didFinish];
  } else {
    NSLog(@"startURLSchemeTask: Did not receive response and data!");
  }
}

- (void)webView:(WKWebView *)webView stopURLSchemeTask:(id<WKURLSchemeTask>)urlSchemeTask {
  NSLog(@"stopURLSchemeTask: url = %@", urlSchemeTask.request.URL);
}

// Handles callbacks from webpage to app.
- (void)webView:(WKWebView *)inWeb decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
  NSLog(@"WKWebView decidePolicyForNavigationAction");
  WKNavigationType inType = navigationAction.navigationType;
  NSURLRequest* request = navigationAction.request;
  NSLog(@"NavigationType: %ld", (long)inType);
  NSLog(@"request: %@", request);
  
  if ([[[request URL] absoluteString] hasPrefix:@"fraxhd://"]
      || [[[request URL] absoluteString] hasPrefix:@"fraxbeta://"]) {
    NSLog(@"Custom URL scheme: ignoring");
    decisionHandler(WKNavigationActionPolicyCancel);
    return;
  }
  
  if ( inType == UIWebViewNavigationTypeLinkClicked ) {
    NSLog(@"WKWebViewNavigationTypeLinkClicked");
    decisionHandler(WKNavigationActionPolicyAllow);
    return;
  }
  
  NSString *requestString = [[[request URL] absoluteString] stringByRemovingPercentEncoding];
  
  if ([requestString hasPrefix:@"ios-cmd:"]) {
    NSString* logString = [[requestString componentsSeparatedByString:@":#iOS#"] objectAtIndex:1];
    NSLog(@"CloudViewController WKWebView console: %@, %@", logString, requestString);
    if ([logString isEqualToString:@"proStatus"]) {
      NSString* script = [NSString stringWithFormat:@"proStatus(%i)", 0];
      NSLog(@"CloudViewController script: %@", script);
      __unused NSString *result = [self stringByEvaluatingJavaScriptFromString:script];
      NSLog(@"CloudViewController script result: %@", result);
      decisionHandler(WKNavigationActionPolicyCancel);
      return;
    }
    NSArray* components = [logString componentsSeparatedByString:@":"];
    if ([components count] == 1 && [[components objectAtIndex:0] isEqualToString:@"details"]) {
      NSLog(@"CloudViewController - details requested (name, comment, Pro status)");
      int proStatus = 0;
      NSString* name = @"";
      NSString* comment = @"";
      NSString* script = [NSString stringWithFormat:@"setDetails(\"%@\", \"%@\", %i)", name, comment, proStatus];
      NSLog(@"CloudViewController script: %@", script);
      __unused NSString *result = [self stringByEvaluatingJavaScriptFromString:script];
      NSLog(@"CloudViewController script result: %@", result);
    }
    NSLog(@"CloudViewController shouldStartLoadWithRequest completed, result = NO");
    decisionHandler(WKNavigationActionPolicyCancel);
    return;
  }
  NSLog(@"CloudViewController shouldStartLoadWithRequest completed, result = YES");
  decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)showSavePage {
  NSLog(@"showSavePage");
  NSString *filePathString = [[NSBundle mainBundle] pathForResource:@"launch_page_save" ofType:@"html"];
  NSURL *srcURL = [NSURL fileURLWithPath:filePathString];
  [webView loadFileURL:srcURL allowingReadAccessToURL:srcURL];
}

- (void)showHiResUpgrade {
  NSLog(@"showHiResUpgrade");
  NSString *filePathString = [[NSBundle mainBundle] pathForResource:@"launch_page_hires" ofType:@"html"];
  NSURL *aURL = [NSURL fileURLWithPath:filePathString];
  NSURLRequest *aRequest = [NSURLRequest requestWithURL:aURL];
  [webView loadRequest:aRequest];
}

- (IBAction)closeButtonClicked:(id)sender {
  FraxAppDelegate* app = (FraxAppDelegate*)[[UIApplication sharedApplication] delegate];
  [app.fraxViewController closeCloudClicked];
}

- (void)viewDidLoad {
  [super viewDidLoad];
  backdropView.center = self.view.center;
  
  // Removes original (IB) WebView, since it is not URLSchemeHandler-compatible.
  webView.backgroundColor = [UIColor blueColor];
  CGRect frame = webView.frame;
  UIView* parent = [webView superview];
  [webView removeFromSuperview];

  // Sets up an URLSchemeHandler-compatible WebView config.
  WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
  // Sets preferred content mode to Mobile. (Fixes issue on iPad OS 15.6+ where
  // the desktop Frax homepage would appear instead of the mobile cloud page.)
  config.defaultWebpagePreferences.preferredContentMode = WKContentModeMobile;
  config.defaultWebpagePreferences.allowsContentJavaScript = YES;
  [config setURLSchemeHandler:self forURLScheme:@"frax-localloader"];

  // Creates the new WebView.
  self.webView = [[WKWebView alloc] initWithFrame:frame configuration:config];
  webView.opaque = NO;
  webView.backgroundColor = [UIColor clearColor];
  webView.autoresizesSubviews = YES;
  webView.autoresizingMask=(UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth);

  [webView setUIDelegate:self];
  [webView setNavigationDelegate:self];

  [parent addSubview: webView];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {}

- (void)webView:(WKWebView *)webView didFailLoadWithError:(NSError *)error {
  NSLog(@"CloudViewController - webView didFailLoadWithError! %@ %@", error, [error userInfo]);
}

@end
