//
//  ExploreViewController.h
//  Frax
//
//  Created by Ben Weiss on 2/5/11
//  Copyright 2011 Shell & Slate Software. All rights reserved.
//

#import <UIKit/UIKit.h>

enum ELeftExploreTab {
	eLeftExploreTabAll,
	eLeftExploreTabColors,
	eLeftExploreTabLights,
	eLeftExploreTexture2s,
	eLeftExploreTabPosition,
	eLeftExploreTabGestures,
	eLeftExploreTabMemory,
	eLeftExploreTabUndo,
	eNumLeftExploreTabs
};

enum ERightExploreTab {
	eRightExploreTabZoomPan,
	eRightExploreTabZoomRotate,
	eRightExploreTabColors,
	eRightExploreTabDepth,
	eRightExploreTabLight1,
	eRightExploreTabLight2,
	eRightExploreTabColorAnim,
	eRightExploreTabHueAnim,

	eNumRightExploreTabs
};

@class FraxViewController; // forward declarations
@class UITab;

@interface ExploreViewController : UIViewController {
	FraxViewController *fraxViewController;
	/*
	IBOutlet UIButton* colorButton;
	IBOutlet UIButton* stripeButton;
	IBOutlet UIButton* lightButton;
	IBOutlet UIButton* placeButton;
	IBOutlet UIButton* styleButton;
	IBOutlet UIButton* weaveButton;
	IBOutlet UIButton* breedButton;
	IBOutlet UIButton* randomButton;
	 */
	IBOutlet UITab* diceTabPresets;
	IBOutlet UITab* diceTabCurrent;
	IBOutlet UITab* diceTabRandom;
	
	//IBOutlet UIButton* undoButton;
	IBOutlet UITab* redoTab;
	
	IBOutlet UIView* noobButtonView;	// big NOOB buttons
	
	IBOutlet UIView* topSubTabView;	// Dice & Gestures
	
	IBOutlet UITab* diceSubTab;
	IBOutlet UITab* gesturesSubTab;
	
	IBOutlet UIView* leftTabView;
	IBOutlet UIView* rightTabView;
	
	IBOutlet UITab* leftTab0;
	IBOutlet UITab* leftTab1;
	IBOutlet UITab* leftTab2;
	IBOutlet UITab* leftTab3;
	IBOutlet UITab* leftTab4;
	IBOutlet UITab* leftTab5;
	IBOutlet UITab* leftTab6;
	IBOutlet UITab* leftTab7;
	
	IBOutlet UITab* rightTab0;
	IBOutlet UITab* rightTab1;
	IBOutlet UITab* rightTab2;
	IBOutlet UITab* rightTab3;
	IBOutlet UITab* rightTab4;
	IBOutlet UITab* rightTab5;
	IBOutlet UITab* rightTab6;
	IBOutlet UITab* rightTab7;
	
	UITab* leftTab[eNumLeftExploreTabs];	// convenient array form
	UITab* rightTab[eNumRightExploreTabs];	// gestures
	UITab* diceTab[3];
	
	UIImageView* diceIcon[3][5];	// all, colors, lights, textures, places
	
	BOOL leftTabsMinimized;
	BOOL rightTabsMinimized;
	
	BOOL edgeSwipe;
	
	int uiHiddenState; // $$$ redundant with FraxViewController??
	BOOL redoTabDisappeared;
	
	NSDate* lastLeftTabClick_;	// to facilitate multiple-selection of left tabs
	
	//BOOL leftTabState[eNumLeftExploreTabs];	// can be multiply-selected
	//int activeLeftTab;
	//int randomIconState;	// which random icon is currently active, from SFraxPreset ERandomizationFlags enums
	int preGestureState;	// to save and restore top left five tabs when Gestures modal state is activated/deactivated
	
	int activeRightTab;	// for Gestures only
	
	
}

- (void)disappear;
- (void)reappear;

- (void)setUIHiddenState:(int)state duration:(float)duration;

- (IBAction)tabTouchDown:(id)sender;
- (IBAction)tabDrag:(id)sender;
- (IBAction)tabTouchUpInside:(id)sender;
- (IBAction)tabTouchUpOutside:(id)sender;

- (void)minimizeLeftTabs:(int)index;
- (void)maximizeLeftTabs;
- (void)minimizeRightTabs;
- (void)maximizeRightTabs;

- (IBAction)clickDice:(id)sender;
- (IBAction)clickUndo:(id)sender;
- (IBAction)clickRedo:(id)sender;

- (IBAction)clickLeftTab:(id)sender;
- (IBAction)clickRightTab:(id)sender;

- (void)updateUndoRedo;

@property (nonatomic, retain) FraxViewController *fraxViewController;

@property (nonatomic, retain) UIView *noobButtonView;

@property (nonatomic, retain)  UITab* diceTabPresets;
@property (nonatomic, retain)  UITab* diceTabCurrent;
@property (nonatomic, retain)  UITab* diceTabRandom;

@property (nonatomic, retain) UIView *leftTabView;
@property (nonatomic, retain) UIView *rightTabView;

@property (nonatomic, retain) UIView* topSubTabView;	// Dice & Gestures

@property (nonatomic, retain) UITab* diceSubTab;
@property (nonatomic, retain) UITab* gesturesSubTab;

@property (nonatomic, retain) UITab *leftTab0;
@property (nonatomic, retain) UITab *leftTab1;
@property (nonatomic, retain) UITab *leftTab2;
@property (nonatomic, retain) UITab *leftTab3;
@property (nonatomic, retain) UITab *leftTab4;
@property (nonatomic, retain) UITab *leftTab5;
@property (nonatomic, retain) UITab *leftTab6;
@property (nonatomic, retain) UITab *leftTab7;

@property (nonatomic, retain) UITab *rightTab0;
@property (nonatomic, retain) UITab *rightTab1;
@property (nonatomic, retain) UITab *rightTab2;
@property (nonatomic, retain) UITab *rightTab3;
@property (nonatomic, retain) UITab *rightTab4;
@property (nonatomic, retain) UITab *rightTab5;
@property (nonatomic, retain) UITab *rightTab6;
@property (nonatomic, retain) UITab *rightTab7;

@property (nonatomic, retain) UITab *redoTab;

@property (nonatomic, retain) NSDate* lastLeftTabClick;

@end
