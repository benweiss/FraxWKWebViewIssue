// *********************************************************************************************************************
// FraxAppDelegate.h
//
// Copyright ©2010-2024 by Ben Weiss, Iter9 LLC
//
// Version: 2.0.2 - August 20th, 2024
// *********************************************************************************************************************

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>   // for In-App Purchase of Pro upgrade
#import <WebKit/WebKit.h>
#import "FixedViewController.h"
#import "TapDetectingWindow.h"

// This domain must be kept in sync with Resources/Content/js/launch.js
#define kCloudDomain @"https://fraxcloud.herokuapp.com"

@class FraxViewController;
@class BackgroundViewController;
@class FraxPreset;

@interface FraxAppDelegate : NSObject <UIApplicationDelegate, UISceneDelegate,
UIWindowSceneDelegate, UINavigationControllerDelegate,
NSNetServiceDelegate, NSNetServiceBrowserDelegate> {
  IBOutlet TapDetectingWindow *tdWindow;
  IBOutlet BackgroundViewController *backgroundViewController;
  IBOutlet FraxViewController *fraxViewController;
  IBOutlet UINavigationController *navigationController;
  IBOutlet UIViewController *navigationRootViewController;
}

-(UIViewController*) rootViewController;
// -(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url;

-(NSUserDefaults*)appDefaults;

@property (nonatomic) NSString* cloudCookie;
@property (nonatomic) NSURL* cloudURL;
@property (nonatomic, strong) UIWindow *window;
@property (nonatomic) IBOutlet UIWindow *tdWindow;
@property (nonatomic) UIWindow* dummyWindow;
@property (nonatomic) UIViewController *dummyViewController;
@property (nonatomic) UIWindow* renderWindow;
@property (nonatomic) FixedViewController *renderViewController;
@property (nonatomic) UIView *renderView;
@property (nonatomic) IBOutlet UILabel *versionLabel;
@property (nonatomic) IBOutlet BackgroundViewController *backgroundViewController;
@property (nonatomic) IBOutlet FraxViewController *fraxViewController;
@property (nonatomic) UINavigationController *navigationController;
@property (nonatomic, readonly) NSString* proUpgradeLocalizedPrice;

@end
