// *********************************************************************************************************************
// FixedViewController.h
//
// Copyright ©2024 by Ben Weiss, Iter9 LLC
//
// Version: 1.1 - July 7th, 2024
// *********************************************************************************************************************

#import <UIKit/UIKit.h>

// FixedViewController - a view controller that doesn't rotate when the device rotates.
@interface FixedViewController : UIViewController {
}
- (UIInterfaceOrientationMask)supportedInterfaceOrientations;
-(BOOL)shouldAutorotate;
@end
