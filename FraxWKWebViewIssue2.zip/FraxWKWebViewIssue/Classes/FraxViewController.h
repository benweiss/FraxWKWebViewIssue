// *********************************************************************************************************************
// FraxViewController.h
//
// Copyright ©2010-2024 by Ben Weiss, Iter9 LLC
//
// Version: 1.3 - August 20th, 2024
// *********************************************************************************************************************

#import <UIKit/UIKit.h>

#import "FraxAppDelegate.h"

@class FraxAppDelegate;
@class FraxViewController;
@class CloudViewController;

@interface UIVideoThumbnailButton : UIButton {
  BOOL longPress;
};
@property (nonatomic) BOOL longPress;
@end;

@interface BackgroundViewController : UIViewController {
  FraxViewController *fraxViewController;
  BOOL edgeSwipe;
};

@property (nonatomic) FraxViewController *fraxViewController;

@end


@interface FraxViewController : UIViewController<UINavigationControllerDelegate, UIActionSheetDelegate, UITextFieldDelegate, UIPopoverControllerDelegate, UIPopoverPresentationControllerDelegate, TapDetectingWindowDelegate> {
  FraxAppDelegate *app;
  BOOL ipad;
  CloudViewController *cloudViewController;
  UIViewController* cloudPopover;
  BOOL cloudPopoverActive;
  UIView* popoverTarget_;
  int popoverWidth;
}

- (IBAction)clickRenderTab:(id)sender;
-(void)closeCloudClicked;

@property (nonatomic) UIView *popoverTarget;
@property (nonatomic, assign, readonly) BOOL cloudPopoverActive;
@property (nonatomic) CloudViewController *cloudViewController;
@property (nonatomic) UIViewController* cloudPopover;

@end
