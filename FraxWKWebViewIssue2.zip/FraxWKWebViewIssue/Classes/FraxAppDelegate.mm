// *********************************************************************************************************************
// FraxAppDelegate - implementation
// Copyright ©2010-2024 by Ben Weiss, Iter9 LLC
// *********************************************************************************************************************

#import "FraxAppDelegate.h"

#import <UIKit/UIKit.h>

#import "FraxViewController.h"
#import "CloudViewController.h"

@implementation FraxAppDelegate
@synthesize tdWindow;
@synthesize backgroundViewController;
@synthesize fraxViewController;
@synthesize navigationController;
@synthesize proUpgradeLocalizedPrice;

- (const struct SFraxPreset*)currentPreset {
  return nil;
}

- (NSString*)prefsPath {
  NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  NSString *documentsDirectory = [paths objectAtIndex:0];
  NSString *path = [documentsDirectory stringByAppendingPathComponent:@"prefs.plist"];
  return path;
}

- (void)defaultsChanged:(NSNotification *)notification {   // reload default settings
  NSLog(@"defaults changed!!");
}

- (void)loadPrefs {
  NSFileManager *fileManager = [NSFileManager defaultManager];
  NSDictionary* prefs = nil;
  
  if ([fileManager fileExistsAtPath: [self prefsPath]]) {
    prefs = [[NSDictionary alloc] initWithContentsOfFile: [self prefsPath]];
    
    if (prefs == nil) { NSLog(@"prefs initWithContentsOfFile returned nil!"); }
  }
  if (prefs != nil) {
    NSLog(@"Loading prefs: %@", prefs);
    
    if (_cloudCookie != nil) {  _cloudCookie = nil; }
    _cloudCookie = [prefs objectForKey:@"cloudCookie"];
  }
  
  // ____ load some prefs through standard iOS Settings
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(defaultsChanged:)
                                               name:NSUserDefaultsDidChangeNotification
                                             object:nil];
  [self defaultsChanged:nil];
}

- (void)savePrefs {
  NSMutableDictionary *prefs = [[NSMutableDictionary alloc] init];
  if (_cloudCookie != nil) {
    [prefs setObject:_cloudCookie forKey:@"cloudCookie"];
  } else {
    NSLog(@"Attempt to set nil Cloud Cookie pref!!");
  }
  NSLog(@"Saving prefs: %@", prefs);
  __unused BOOL success = [prefs writeToFile: [self prefsPath] atomically:YES];
  NSLog(@"savePrefs success = %d", success);
}

-(void)setPrefResetTutorials:(BOOL)reset {
  NSLog(@"setPrefResetTutorials to %@", reset ? @"YES" : @"NO");
  
  NSUserDefaults* defaults = [self appDefaults];
  [defaults setBool:reset forKey:@"intro_video_preference"];
  [defaults synchronize];
}

-(UIWindow*) window {
  return tdWindow;
}

-(UIViewController*) rootViewController {
  return [tdWindow rootViewController];
}

- (UIInterfaceOrientationMask)navigationControllerSupportedInterfaceOrientations:(UINavigationController *)navigationController {
  return UIInterfaceOrientationMaskAll;
}

- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
  return UIInterfaceOrientationMaskAll;
}

- (void) applicationDidFinishLaunching:(UIApplication *)application {
  NSLog(@"applicationDidFinishLaunching");
  
  NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
  NSString *bundleVersion = [infoDictionary valueForKey:@"CFBundleVersion"];
  NSLog(@"Bundle version in plist = %@", bundleVersion);

  // Sets the user agent pref.
  {
    NSString *deviceType = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad ? @"iPad" : @"iPhone";
    NSString *proMode = @"Pro";
    NSString *userAgent = [NSString stringWithFormat:@"Frax HD %@ %@ %@", proMode, bundleVersion, deviceType];
    NSUserDefaults* defaults = self.appDefaults;
    [defaults registerDefaults:@{ @"UserAgent": userAgent }];
    NSLog(@"Setting UserAgent: %@", userAgent);
  }

  backgroundViewController = [[BackgroundViewController alloc] init];
  backgroundViewController.view = [[UIView alloc] initWithFrame:[self tdWindow].frame];
  backgroundViewController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  backgroundViewController.fraxViewController = fraxViewController;

  tdWindow.rootViewController = backgroundViewController;
  
  backgroundViewController.view.clipsToBounds = NO; // diagnostic for rotation issues
  backgroundViewController.view.backgroundColor = [UIColor clearColor];
  tdWindow.rootViewController.view.backgroundColor = [UIColor clearColor];
  tdWindow.backgroundColor = [UIColor clearColor];
  tdWindow.opaque = NO;
  tdWindow.clipsToBounds = NO;
  
  [[self tdWindow] addSubview:backgroundViewController.view];
  [backgroundViewController.view addSubview:fraxViewController.view];
    
  backgroundViewController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  fraxViewController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  {
    CGRect bounds = backgroundViewController.view.bounds;
    CGRect frame = bounds;
    fraxViewController.view.frame = frame;
    fraxViewController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  }
    
  tdWindow.controllerThatObserves = fraxViewController;
  [self.dummyWindow resignKeyWindow];
  [self.renderWindow resignKeyWindow];
  [self.tdWindow makeKeyAndVisible];

  tdWindow.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
  [fraxViewController.view addSubview:[navigationController view]];
  [navigationController setToolbarHidden:YES animated:NO];
  navigationController.view.alpha = 0.0;
  navigationController.view.frame = fraxViewController.view.frame;
  navigationController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  navigationController.view.backgroundColor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:0.8];
  navigationController.delegate = fraxViewController;
  navigationController.navigationBar.barStyle = UIBarStyleDefault;
  navigationController.navigationBar.translucent = YES;
  navigationController.navigationBar.tintColor = [UIColor colorWithWhite:0.0f alpha:0.5f];
  
  self.dummyWindow.hidden = NO;
  self.renderWindow.hidden = NO;

  // Workaround for iOS 11 bug where foreground taps are not detected.
  BOOL ios11 = [[[UIDevice currentDevice] systemVersion] intValue] >= 11;
  if (ios11) {
    [self.tdWindow setHidden:YES];
    [self.tdWindow setHidden:NO];
    
    [self.tdWindow makeKeyAndVisible];
  }
  
  // For purposes of demonstrating the issue, attempt to load the web view on launch.
  [fraxViewController clickRenderTab:nil];
}

- (void) applicationWillResignActive:(UIApplication *)application {}
- (void) applicationDidBecomeActive:(UIApplication *)application {}
- (void) applicationWillTerminate:(UIApplication *)application {}

- (NSUserDefaults*)appDefaults {
  return [NSUserDefaults standardUserDefaults];
}

// The issue can be demonstrated without any of this code. When the user taps the 'close' button
// on the Cloud web view, it sends a custom URL scheme message to the app to close the window,
// which is received here.
#if 0
- (BOOL)application:(UIApplication*)application openURL:(nonnull NSURL *)url
            options:(nonnull NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
  if (!url)  { NSLog(@"Frax openURL with nil URL!"); return NO; }
  NSLog(@"Someone just opened us with an URL! %@", [url absoluteString]);
  return [self application:application handleOpenURL:url];
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
  if (!url)  { NSLog(@"Frax handleOpenURL with nil URL!"); return NO; }
  NSString *URLString = [url absoluteString];
  NSLog(@"Someone just opened us with an URL! %@", URLString);
  NSString *request = URLString;
  if ([request hasPrefix:@"fraxbeta://"]) {
    request = [request
               stringByReplacingCharactersInRange: [request rangeOfString:@"fraxbeta://"]
               withString:                         @"fraxhd://"];
  }
  
  // ____ check if URL string starts with "fraxhd:"
  if ([request hasPrefix:@"fraxhd://"]) {
    // ____ strip prefix
    request = [request substringFromIndex:[@"fraxhd://" length]];
    
    if ([request isEqualToString:@"close"]) {
      NSLog(@"Received custom url link to close cloud window");
      [fraxViewController closeCloudClicked];
      return YES;
    }
    
    if ([request isEqualToString:@"proupgrade"]) {
      NSLog(@"Received custom url link to show Frax Pro Upgrade");
      return YES;
    }
    if ([request rangeOfString:@"upload"].location == 0) {
      return YES;
    }
    NSRange qmark = [request rangeOfString:@"?"];
    if (qmark.length != 0) {
      // remove "?ref=nf" from facebook action links
      request = [request substringToIndex:(qmark.location)];
    }
    if (fraxViewController == nil)  {
      NSLog(@"handleOpenURL failed because fraxViewController = nil!"); return YES;
    }
    NSRange slash = [request rangeOfString:@"/"];
    if (slash.length != 0) {    // string contains slashes, treat it as a complete URL
      request = [NSString stringWithFormat:@"%@%@", @"http://", request]; // add http://
      return YES;
    } else {  // treat it as just the raw preset name -- no longer used
      return YES;
    }
  }
  return YES;
}
#endif

@end
