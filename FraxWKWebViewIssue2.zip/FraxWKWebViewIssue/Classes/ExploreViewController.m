//
//  ExploreViewController.m
//  Frax
//
//  Created by Ben Weiss on 6/8/10.
//  Copyright 2010 Shell & Slate Software. All rights reserved.
//

#import "ExploreViewController.h"
#import "FraxViewController.h"

#import "ES2Renderer.h"


@implementation ExploreViewController

@synthesize fraxViewController;

@synthesize noobButtonView;

@synthesize diceTabPresets;
@synthesize diceTabCurrent;
@synthesize diceTabRandom;

@synthesize leftTabView;
@synthesize rightTabView;

@synthesize topSubTabView;	// Dice & Gestures

@synthesize diceSubTab;
@synthesize gesturesSubTab;

@synthesize leftTab0;
@synthesize leftTab1;
@synthesize leftTab2;
@synthesize leftTab3;
@synthesize leftTab4;
@synthesize leftTab5;
@synthesize leftTab6;
@synthesize leftTab7;

@synthesize rightTab0;
@synthesize rightTab1;
@synthesize rightTab2;
@synthesize rightTab3;
@synthesize rightTab4;
@synthesize rightTab5;
@synthesize rightTab6;
@synthesize rightTab7;

@synthesize redoTab;

@synthesize lastLeftTabClick=lastLeftTabClick_;

- (void) leftTabDisappear:(UITab*)object
{
	object.disappeared = YES;
}

- (void) leftTabReappear:(UITab*)object
{
	object.disappeared = NO;
	
	if (object == leftTab[eLeftExploreTabUndo]) [self updateUndoRedo];
}

- (void) rightTabDisappear:(UITab*)object
{
	object.disappeared = YES;
}

- (void) rightTabReappear:(UITab*)object
{
	object.disappeared = NO;
}

- (void) diceTabDisappear:(UITab*)object
{
	object.disappeared = YES;
}

- (void) diceTabReappear:(UITab*)object
{
	object.disappeared = NO;
	return;
	
#if 0 // old way
	int tag = object.tag;
	
	UIImage* diceImage = nil;
	
	switch (randomIconState) {
		case eRandomizeGradient: {
			switch (tag) {
				case 0: diceImage = [UIImage imageNamed:@"dicecolorspresets.png"]; break;
				case 1: diceImage = [UIImage imageNamed:@"dicecolorscurrent.png"]; break;
				case 2: diceImage = [UIImage imageNamed:@"dicecolorsrandom.png"]; break;
			} break;
		} break;
		case eRandomizeStripes: {
			switch (tag) {
				case 0: diceImage = [UIImage imageNamed:@"dicestripespresets.png"]; break;
				case 1: diceImage = [UIImage imageNamed:@"dicestripescurrent.png"]; break;
				case 2: diceImage = [UIImage imageNamed:@"dicestripesrandom.png"]; break;
			} break;
		} break;
		case eRandomizeDepth: {
			switch (tag) {
				case 0: diceImage = [UIImage imageNamed:@"dicelightspresets.png"]; break;
				case 1: diceImage = [UIImage imageNamed:@"dicelightscurrent.png"]; break;
				case 2: diceImage = [UIImage imageNamed:@"dicelightsrandom.png"]; break;
			} break;
		} break;
		/*
		case eLeftExploreTabStyle: {
			switch (tag) {
				case 0: diceImage = [UIImage imageNamed:@"dicestylepresets.png"]; break;
				case 1: diceImage = [UIImage imageNamed:@"dicestylecurrent.png"]; break;
				case 2: diceImage = [UIImage imageNamed:@"dicestylerandom.png"]; break;
			} break;
		} break;
		 */
		case eRandomizeLocation: {
			switch (tag) {
				case 0: diceImage = [UIImage imageNamed:@"diceplacespresets.png"]; break;
				case 1: diceImage = [UIImage imageNamed:@"diceplacescurrent.png"]; break;
				case 2: diceImage = [UIImage imageNamed:@"diceplacesrandom.png"]; break;
			} break;
		} break;
		case eRandomizeAll: {
			switch (tag) {
				case 0: diceImage = [UIImage imageNamed:@"diceallpresets.png"]; break;
				case 1: diceImage = [UIImage imageNamed:@"diceallcurrent.png"]; break;
				case 2: diceImage = [UIImage imageNamed:@"diceallrandom.png"]; break;
			} break;
		} break;
		default: {
			NSLog(@"Unsupported randomIconState: %d", randomIconState);	// $$$
		}
	};
	
	if (diceImage) {
		[object setBackgroundImage:diceImage forState:UIControlStateNormal];
	}
	else {
		NSLog(@"No image found for random state %d, dice button %d", randomIconState, tag);	// $$$
	}
	
	object.disappeared = NO;
	
#endif
}



- (void) redoTabDisappear:(UITab*)object
{
	if (redoTabDisappeared)	return;
	redoTabDisappeared = YES;
	
	// ____ exit stage left
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2f];
	[UIView setAnimationBeginsFromCurrentState:YES];	// in case it happens simultaneously with Minimize/Maximize
	
	// ____ expand undo tab (if applicable)
	{
		CGRect frame = leftTab[eLeftExploreTabUndo].frame;
		if (frame.origin.x < 0.0f) {	// don't expand the very first time
			frame.origin.x += 22.0f;
			leftTab[eLeftExploreTabUndo].frame = frame;
			
			frame = leftTab[eLeftExploreTabUndo].labellit.frame;
			frame.origin.x -= 11.0f;
			leftTab[eLeftExploreTabUndo].labellit.frame = frame;
		}
	}
	
	CGRect frame = redoTab.frame;
	frame.origin.x -= frame.size.width / 4;
	redoTab.frame = frame;
	
	redoTab.alpha = 0.0f;
	
	[UIView commitAnimations];
}

- (void) redoTabReappear:(UITab*)object
{
	if (!redoTabDisappeared)	return;
	redoTabDisappeared = NO;
	
	// ____ enter stage left
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2f];
	[UIView setAnimationBeginsFromCurrentState:YES];	// in case it happens simultaneously with Minimize/Maximize
	
	// ____ contract undo tab
	{
		CGRect frame = leftTab[eLeftExploreTabUndo].frame;
		frame.origin.x -= 22.0f;
		leftTab[eLeftExploreTabUndo].frame = frame;
		
		frame = leftTab[eLeftExploreTabUndo].labellit.frame;
		frame.origin.x += 11.0f;
		leftTab[eLeftExploreTabUndo].labellit.frame = frame;
	}
	
	CGRect frame = redoTab.frame;
	frame.origin.x += frame.size.width / 4;
	redoTab.frame = frame;
	redoTab.alpha = leftTab[eLeftExploreTabUndo].alpha;	// mirror undo tab state
	
	[UIView commitAnimations];
}



- (void)hideSelf:(id)object {
	self.view.hidden = YES;
}

- (void)disappearLeftTabsWithStagger:(float)stagger {
	int ind;
	for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
		[self performSelector:@selector(leftTabDisappear:) withObject:leftTab[ind] afterDelay:0.0f + stagger * ind];	// flutter left tabs out
	}
	
	[self performSelector:@selector(redoTabDisappear:) withObject:redoTab afterDelay:0.0f + stagger * eNumLeftExploreTabs];
}

- (void)reappearLeftTabsWithStagger:(float)stagger delay:(float)delay {
	int ind;
	for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
		[self performSelector:@selector(leftTabReappear:) withObject:leftTab[ind] afterDelay:delay + stagger * ind];	// flutter left tabs in
	}
}

- (void)disappearRightTabsWithStagger:(float)stagger {
	int ind;
	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
		[self performSelector:@selector(rightTabDisappear:) withObject:rightTab[ind] afterDelay:0.0f + stagger * ind];	// flutter right tabs out
	}
	
	[self performSelector:@selector(redoTabDisappear:) withObject:redoTab afterDelay:0.0f + stagger * eNumRightExploreTabs];
}

- (void)reappearRightTabsWithStagger:(float)stagger delay:(float)delay {
	int ind;
	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
		[self performSelector:@selector(rightTabReappear:) withObject:rightTab[ind] afterDelay:delay + stagger * ind];	// flutter left tabs in
	}
}


- (void)disappearDiceTabsWithStagger:(float)stagger {
	int ind;
	for (ind = 0; ind < 3; ind++) {
		[self performSelector:@selector(diceTabDisappear:) withObject:diceTab[ind] afterDelay:0.0f + stagger * ind];	// flutter right tabs out
	}
}

- (void)reappearDiceTabsWithStagger:(float)stagger delay:(float)delay {
	int ind;
	
	for (ind = 0; ind < 3; ind++) {
		[self performSelector:@selector(diceTabReappear:) withObject:diceTab[ind] afterDelay:delay + stagger * ind];	// flutter left tabs in
	}
}

- (void)disappear {
	int ind;
    
    self.view.hidden = YES;
	
	//[self disappearLeftTabsWithStagger:0.03f];
	//[self disappearRightTabsWithStagger:0.03f];
	/*
	for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
		[self performSelector:@selector(leftTabDisappear:) withObject:leftTab[ind] afterDelay:0.0f + 0.03f * ind];	// flutter left tabs out
	}
	
	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
		[self performSelector:@selector(rightTabDisappear:) withObject:leftTab[ind] afterDelay:0.0f + 0.03f * ind];	// flutter right tabs out
	}
	*/
	
	
	for (ind = 0; ind < 3; ind++) {
		[self performSelector:@selector(diceTabDisappear:) withObject:diceTab[ind] afterDelay:0.0f + 0.08f * ind];	// flutter bottom tabs out
	}
	
	[self performSelector:@selector(hideSelf:) withObject:nil afterDelay:0.5f];	// half-second later, hide ourself completely
}

- (void)reappear {
	self.view.hidden = NO;
    
    [fraxViewController showGesturesTabsAfterDelay:0.2f];
	/*
	if (false) { // ([fraxViewController gestureTabView].hidden) {	// show dice
		NSLog(@"Explore reappear - avc gestureTabView hidden, showing dice");
		[self tabTouchUpInside:diceSubTab];
	}
	else {
		NSLog(@"Explore reappear - avc gestureTabView visible, not showing dice");
		[self tabTouchUpInside:gesturesSubTab];
	}
	
	
	[self reappearLeftTabsWithStagger:0.03f delay:0.2f];
     */
    
	/*
	if (leftTab[eLeftExploreTabGestures].selected) {
		[self reappearRightTabsWithStagger:0.03f delay:0.2f];
	}
	else {
		 int ind; 
		for (ind = 0; ind < 3; ind++) {
			[self performSelector:@selector(diceTabReappear:) withObject:diceTab[ind] afterDelay:0.0f + 0.08f * ind];	// flutter bottom tabs out
		}
	}
	*/
	
	/*
	for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
		[self performSelector:@selector(leftTabReappear:) withObject:leftTab[ind] afterDelay:0.2f + 0.03f * ind];	// flutter left tabs in
	}
	 
	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
		[self performSelector:@selector(rightTabReappear:) withObject:leftTab[ind] afterDelay:0.2f + 0.03f * ind];	// flutter right tabs in
	}
	*/
	
}

- (void)setUIHiddenState:(int)state duration:(float)duration {
	//NSLog(@"DesignViewController -- setUIHiddenState %d with current state %d", state, uiHiddenState);
	if (state == uiHiddenState)	return;
	
	// ____ old & new literal states for purposes of hiding/showing
	int oldHiddenState = (uiHiddenState & eTabUITempHidden) ? eTabUIHidden : uiHiddenState;
	int newHiddenState = (state & eTabUITempHidden) ? eTabUIHidden : state;
	
	uiHiddenState = state;	// set with proper temp hidden bit
	
	if (oldHiddenState == newHiddenState)	return;	// e.g. temp hidden vs non-temp hidden
	
	BOOL topVisible = (oldHiddenState == eTabUIVisible || oldHiddenState == eTabUITopOnly || oldHiddenState == eTabUITopBottom);
	BOOL bottomVisible = (oldHiddenState == eTabUIVisible || oldHiddenState == eTabUIBottomOnly || oldHiddenState == eTabUITopBottom);
	BOOL sidesVisible = (oldHiddenState == eTabUIVisible);
	
	BOOL makeTopVisible = (newHiddenState == eTabUIVisible || newHiddenState == eTabUITopOnly || newHiddenState == eTabUITopBottom);
	BOOL makeBottomVisible = (newHiddenState == eTabUIVisible || newHiddenState == eTabUIBottomOnly || newHiddenState == eTabUITopBottom);
	BOOL makeSidesVisible = (newHiddenState == eTabUIVisible);
	
	float topMult = (topVisible ? -1 : 0) + (makeTopVisible ? 1 : 0);
	float leftMult = (sidesVisible ? -1 : 0) + (makeSidesVisible ? 1 : 0);
	float rightMult = -leftMult;
	float bottomMult = (bottomVisible ? 1 : 0) + (makeBottomVisible ? -1 : 0);
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:duration];
	
	//CGRect frameh = helpTab.frame;
	//CGRect frameg = goawayTab.frame;
	CGRect framet = topSubTabView.frame;
	CGRect framel = leftTabView.frame;
	CGRect framels = redoTab.frame;
	CGRect framer = rightTabView.frame;
	//CGRect framef = rightSubTabView.frame;	// float tabs follow rightMult
	CGRect frameb = noobButtonView.frame;
	
	//topTabView.alpha =
	//leftTabView.alpha = leftSubTabView.alpha = rightTabView.alpha = rightSubTabView.alpha = bottomTabView.alpha = 1.0f;	// show all fully visible $$$$ maybe only if unhiding??
	
	// ____ physically move tabs
	framet.origin.y += framet.size.height * topMult;
	framel.origin.x += framel.size.width * leftMult;
	framels.origin.x += framels.size.width * leftMult;
	framer.origin.x += framer.size.width * rightMult;
	frameb.origin.y += frameb.size.height * bottomMult;
	//framef.origin.x += framef.size.width * rightMult;
	//framef.origin.y += framef.size.height * rightMult * 3.0f;	// track rightMult, but downwards
	
	//helpTab.frame = frameh;
	//goawayTab.frame = frameg;
	topSubTabView.frame = framet;
	leftTabView.frame = framel;
	redoTab.frame = framels;
	rightTabView.frame = framer;
	//rightSubTabView.frame = framef;
	noobButtonView.frame = frameb;
	
	//uiHiddenState = state;
	
	[UIView commitAnimations];
	
	[fraxViewController setUIHiddenState:uiHiddenState duration:duration];
}

- (void)clickDice:(UITab*)sender {
	//NSLog(@"Dice Clicked");
	/*
	int flags = 0;
	
	switch (activeLeftTab) {
		case eLeftExploreTabColors:		flags = eRandomizeGradient | eRandomizeColorMeta;		break;
		case eLeftExploreTexture2s:	flags = eRandomizeStripes;		break;
		case eLeftExploreTabLights:		flags = eRandomizeDepth;			break;
		//case eLeftExploreTabStyle:		flags = eRandomizeGradient | eRandomizeColorMeta | eRandomizeStripes | eRandomizeDepth;			break;
		case eLeftExploreTabPosition:	flags = eRandomizeLocation;		break;
		case eLeftExploreTabAll:		flags = eRandomizeAll;			break;
	};
	*/
	int tag = sender.tag;	// 0 = Presets, 1 = Current, 2 = Random
	
	
	
	int randomFlags = 0;
	if (leftTab[eLeftExploreTabAll].selected)	randomFlags |= eRandomizeAll;
	if (leftTab[eLeftExploreTabColors].selected)	randomFlags |= eRandomizeGradient | eRandomizeColors;
	if (leftTab[eLeftExploreTexture2s].selected)	randomFlags |= eRandomizeTextures;
	if (leftTab[eLeftExploreTabLights].selected)	randomFlags |= eRandomizeLights;
	if (leftTab[eLeftExploreTabPosition].selected)	randomFlags |= eRandomizeLocation;
	
	NSLog(@"Dice clicked: random flags = %d, Bottom tab = %d", randomFlags, tag);	// $$$
	
	switch (tag) {
		case 0: {	// Presets
			if (leftTab[eLeftExploreTabAll].selected) {	// all from different presets
				RandomizeAllFromPresets();
			}
			else {
				RandomizeFromPreset(randomFlags);	// subset, possibly all, from a single preset
			}
		}; break;
			
		case 1: {	// Current
			Randomize(randomFlags, 0.2f);
			
		}; break;
			
		case 2: {	// Random
			Randomize(randomFlags, 1.0f);
		}; break;
	};
		
	//NSLog(@"Unknown dice clicked!!");
}

- (void)minimizeLeftTabs:(int)index
{
	if (index < 0 || index >= eNumLeftExploreTabs) { NSLog(@"Minimize to illegal tab: %d", index); return; }
	
	UITab* target = leftTab[index];
	if (target == nil)	{ NSLog(@"Minimize to nil tab: %d", index); return; }
	
	//if (leftTabsMinimized || activeLeftTab == -1)	return;
	/*
	 if (uiHiddenState == eTabUIVisible)
	 [self playClickSound];
	 */
	//AudioServicesPlaySystemSound (clickSound);
	
	float targetOrigY = target.frame.origin.y;
	
	[self redoTabDisappear:redoTab];
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2f];
	[UIView setAnimationBeginsFromCurrentState:YES];	// for Undo/Redo, which may be animating themselves
	
	target.expandImageView.alpha = 0.42f;	// fade in up-down arrows
	
	int ind;
	for (ind = 0; ind <= eNumLeftExploreTabs; ind++) {
		UITab* tab = ind < eNumLeftExploreTabs ? leftTab[ind] : redoTab;
		
		CGRect frame = tab.frame;
		frame.origin.y = targetOrigY;
		tab.frame = frame;
		
		if (tab != target)	tab.alpha = 0.0f;	// disappear all except current!
	}
	
	[UIView commitAnimations];
	
	leftTabsMinimized = YES;
}

- (void)maximizeLeftTabs
{
	if (!leftTabsMinimized)	return;	// tabs not minimized, do nothing
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2f];
	[UIView setAnimationBeginsFromCurrentState:YES];	// for Undo/Redo, which may be animating themselves
	
	//leftTab[activeLeftTab].expandImageView.alpha = 0.0f;
	
	int ind;
	for (ind = 0; ind <= eNumLeftExploreTabs; ind++) {
		UITab* tab = ind < eNumLeftExploreTabs ? leftTab[ind] : redoTab;
		CGRect frame = tab.frame;
		frame.origin.y = tab.origFrame.origin.y;
		tab.frame = frame;
		tab.alpha = 1.0f;
		tab.expandImageView.alpha = 0.0f;	// do this for all, since we don't know which one was minimized to
	}
	
	[UIView commitAnimations];
	
	leftTabsMinimized = NO;
	
	[self updateUndoRedo];	// touch up undo/redo tabs if necessary
}

- (void)minimizeRightTabs
{
	if (rightTabsMinimized || activeRightTab == -1)	return;
	/*
	 if (uiHiddenState == eTabUIVisible)
	 [self playClickSound];
	 */
	//AudioServicesPlaySystemSound (clickSound);
	
	float targetOrigY = rightTab[activeRightTab].frame.origin.y;
		
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2f];
	
	rightTab[activeRightTab].expandImageView.alpha = 0.42f;	// fade in up-down arrows
	
	int ind;
	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
		UITab* tab = rightTab[ind];
		
		CGRect frame = tab.frame;
		frame.origin.y = targetOrigY;
		tab.frame = frame;
		
		if (tab != rightTab[activeRightTab])	tab.alpha = 0.0f;	// disappear all except current!
	}
	
	[UIView commitAnimations];
	
	rightTabsMinimized = YES;
}

- (void)maximizeRightTabs
{
	if (!rightTabsMinimized)	return;	// tabs not minimized, do nothing
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2f];
	
	rightTab[activeRightTab].expandImageView.alpha = 0.0f;
	
	int ind;
	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
		UITab* tab = rightTab[ind];
		CGRect frame = tab.frame;
		frame.origin.y = tab.origFrame.origin.y;
		tab.frame = frame;
		tab.alpha = 1.0f;
	}
	
	[UIView commitAnimations];
	
	rightTabsMinimized = NO;
}


- (void)clickUndo:(UIButton*)sender {
	NSLog(@"Undo Clicked");
	Undo();
	[fraxViewController updateUndoRedo];
}

- (void)clickRedo:(UIButton*)sender {
	NSLog(@"Redo Clicked");
	Redo();
	[fraxViewController updateUndoRedo];
}
/*
- (void)setActiveLeftTab:(int)newind {
	if (activeLeftTab == newind)	return;	// degenerate case
	
	activeLeftTab = newind;
	
	float delay = 0.0f;
	
	if (diceTab[0].disappeared == NO) {
		int ind;
		for (ind = 0; ind < 3; ind++) {
			[self performSelector:@selector(diceTabDisappear:) withObject:diceTab[ind] afterDelay:delay + 0.03f * ind];	// flutter dice tabs out
		}
		
		delay += 0.2f;
	}
	
	if (activeLeftTab >= 0 && activeLeftTab < 5) {	// new dice tab selected: flutter in
		int ind;
		for (ind = 0; ind < 3; ind++) {
			[self performSelector:@selector(diceTabReappear:) withObject:diceTab[ind] afterDelay:delay + 0.03f * ind];	// flutter dice tabs in
		}
	}
		
	int ind;
	for (ind = 0; ind < 5; ind++) {	// Gestures/Memory/Undo don't get selected
		leftTab[ind].selected = (newind == ind);
	}
}
*/
- (void)setActiveRightTab:(int)newind {
	if (activeRightTab == newind)	return;	// degenerate case
	
	activeRightTab = newind;
	
	int ind;
	for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
		rightTab[ind].selected = (newind == ind);
	}
}

// ____ set random icon state and flutter tabs if it changes
- (void)setRandomIconState {
	
	int numSelected = 0;
	if (leftTab[eLeftExploreTabAll].selected)		numSelected++;
	if (leftTab[eLeftExploreTabColors].selected)	numSelected++;
	if (leftTab[eLeftExploreTabLights].selected)	numSelected++;
	if (leftTab[eLeftExploreTexture2s].selected)	numSelected++;
	if (leftTab[eLeftExploreTabPosition].selected)	numSelected++;
	
	int stagger = 15;
	int xstart = 75 - stagger * numSelected;
	int ystart = numSelected <= 1 ? 0 : -12;
	
	CGRect frame0 = diceIcon[0][1].frame;	// just to get frame bounds
	
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2f];
	
	
	int ind;
	for (ind = 0; ind < 3; ind++) {
		CGRect frame = frame0;
		frame.origin.x = xstart;
		frame.origin.y = ystart;
		
		if (numSelected == 0) {	// e.g. if Gestures is shown, hiding the Dice tabs
			diceIcon[ind][0].alpha = 0.0f;
			diceIcon[ind][1].alpha = 0.0f;
			diceIcon[ind][2].alpha = 0.0f;
			diceIcon[ind][3].alpha = 0.0f;
			diceIcon[ind][4].alpha = 0.0f;
		}
		else if (leftTab[eLeftExploreTabAll].selected) {	// "All" selected -- show just the basic dice
			diceIcon[ind][0].frame = frame;
			diceIcon[ind][0].alpha = 1.0f;
			
			diceIcon[ind][1].alpha = 0.0f;
			diceIcon[ind][2].alpha = 0.0f;
			diceIcon[ind][3].alpha = 0.0f;
			diceIcon[ind][4].alpha = 0.0f;
		}
		else {
			diceIcon[ind][0].alpha = 0.0f;
			
			diceIcon[ind][1].frame = frame;
			diceIcon[ind][1].alpha = (leftTab[eLeftExploreTabColors].selected) ? 1.0f : 0.0f;
			if (leftTab[eLeftExploreTabColors].selected)	frame.origin.x += stagger;
			
			diceIcon[ind][2].frame = frame;
			diceIcon[ind][2].alpha = (leftTab[eLeftExploreTabLights].selected) ? 1.0f : 0.0f;
			if (leftTab[eLeftExploreTabLights].selected)	frame.origin.x += stagger;
			
			diceIcon[ind][3].frame = frame;
			diceIcon[ind][3].alpha = (leftTab[eLeftExploreTexture2s].selected) ? 1.0f : 0.0f;
			if (leftTab[eLeftExploreTexture2s].selected)	frame.origin.x += stagger;
			
			diceIcon[ind][4].frame = frame;
			diceIcon[ind][4].alpha = (leftTab[eLeftExploreTabPosition].selected) ? 1.0f : 0.0f;
		}
	}
	
	
	[UIView commitAnimations];
	
	/*
	if (state == randomIconState)	return;	// degenerate case
	if (state != eRandomizeAll && state != eRandomizeGradient && state != eRandomizeDepth && state != eRandomizeStripes && state != eRandomizeLocation) {
		NSLog(@"Unknown random icon state encountered!! %d", state);	// reality check
		return;
	}
	
	[self disappearDiceTabsWithStagger:0.03f];
	randomIconState = state;
	[self reappearDiceTabsWithStagger:0.03f delay:0.2f];
	*/
}


- (void)clickLeftTab:(UITab*)sender {	
	int tag = sender.tag;	// 0..7
	
	// ____ If minimzed, maximize
	if (leftTabsMinimized) {
		[self maximizeLeftTabs];
		return;
	}
	
	// ____ Handle Undo first as a special case
	if (tag == eLeftExploreTabUndo)	{
		Undo();
		[fraxViewController updateUndoRedo];
		return;
	}
	
	// ____ if clicking away from Gestures, hide Gestures and restore randomization state
	if (leftTab[eLeftExploreTabGestures].selected && tag != eLeftExploreTabGestures) {
		leftTab[eLeftExploreTabGestures].selected = NO;
		[self disappearRightTabsWithStagger:0.03f];	// flutter out right tabs
		
		[self reappearDiceTabsWithStagger:0.08 delay:0.0f];
		
		if (tag == eLeftExploreTabMemory) {	// restore state exactly
			// ____ restore previous random state
			leftTab[eLeftExploreTabAll].selected      = (preGestureState == 0);
			leftTab[eLeftExploreTabColors].selected   = (preGestureState & 1) != 0;
			leftTab[eLeftExploreTabLights].selected   = (preGestureState & 2) != 0;
			leftTab[eLeftExploreTexture2s].selected  = (preGestureState & 4) != 0;
			leftTab[eLeftExploreTabPosition].selected = (preGestureState & 8) != 0;
			
			[self setRandomIconState];
		}
		// ____ otherwise, one of the first five tabs is clicked, and the random icon state will set itself below
	}
	
	// ____ Handle click on All
	if (tag == eLeftExploreTabAll) {
		if (leftTab[eLeftExploreTabAll].selected) {
			[self minimizeLeftTabs:eLeftExploreTabAll];
			return;
		}
		
		leftTab[eLeftExploreTabAll].selected      = YES;
		leftTab[eLeftExploreTabColors].selected   = NO;
		leftTab[eLeftExploreTabLights].selected   = NO;
		leftTab[eLeftExploreTexture2s].selected  = NO;
		leftTab[eLeftExploreTabPosition].selected = NO;
		
		[self setRandomIconState];
		return;
	}
	
	if (tag == eLeftExploreTabColors || tag == eLeftExploreTabLights || tag == eLeftExploreTexture2s || tag == eLeftExploreTabPosition) {
		int numSelected = 0;
		BOOL multitap = [self.lastLeftTabClick timeIntervalSinceNow] > -0.8f;
		
		// NSLog(@"multitap timeIntervalSinceNow:%f", [self.lastLeftTabClick timeIntervalSinceNow]);	// $$$
		
		self.lastLeftTabClick = [NSDate date];
		
		if (leftTab[eLeftExploreTabColors].selected)	numSelected++;
		if (leftTab[eLeftExploreTabLights].selected)	numSelected++;
		if (leftTab[eLeftExploreTexture2s].selected)	numSelected++;
		if (leftTab[eLeftExploreTabPosition].selected)	numSelected++;
		
		if (sender.selected && numSelected == 1) {	// if user taps the only one selected, minimize
			[self minimizeLeftTabs:tag];
		}
		else if (sender.selected && numSelected > 1) {	// multiple selection already, deselect the tapped one
			if (multitap) {	// stay selected -- do nothing!
				//sender.selected = false;
				//numSelected--;
			}
			else {
				leftTab[eLeftExploreTabColors].selected   = (tag == eLeftExploreTabColors);
				leftTab[eLeftExploreTabLights].selected   = (tag == eLeftExploreTabLights);
				leftTab[eLeftExploreTexture2s].selected  = (tag == eLeftExploreTexture2s);
				leftTab[eLeftExploreTabPosition].selected = (tag == eLeftExploreTabPosition);
				//numSelected = 1;
			}
			
		}
		else if (numSelected == 0) {	// make single selection, deselect 'All' tab
			leftTab[eLeftExploreTabAll].selected      = NO;
			sender.selected                           = YES;
			//numSelected = 1;
		}
		else if (multitap) {	// make multiple selection
			leftTab[eLeftExploreTabAll].selected      = NO;
			sender.selected                           = YES;
			//numSelected++;
		}
		else {	// select this one, deselect others
			leftTab[eLeftExploreTabAll].selected      = NO;
			leftTab[eLeftExploreTabColors].selected   = (tag == eLeftExploreTabColors);
			leftTab[eLeftExploreTabLights].selected   = (tag == eLeftExploreTabLights);
			leftTab[eLeftExploreTexture2s].selected  = (tag == eLeftExploreTexture2s);
			leftTab[eLeftExploreTabPosition].selected = (tag == eLeftExploreTabPosition);
			//numSelected = 1;
		}
		
		
		[self setRandomIconState];	// set random icon state based on selected West tabs
		
		return;	// end of 1..4 cases
	}
	
	if (tag == eLeftExploreTabGestures) {
		
		if (sender.selected) {
			sender.selected = NO;
			[self disappearRightTabsWithStagger:0.03f];	// flutter out right tabs
			NSLog(@"Disappearing Gestures: preGestureState = %d", preGestureState);	// $$$
			
			// ____ restore previous random state
			leftTab[eLeftExploreTabAll].selected      = (preGestureState == 0);
			leftTab[eLeftExploreTabColors].selected   = (preGestureState & 1) != 0;
			leftTab[eLeftExploreTabLights].selected   = (preGestureState & 2) != 0;
			leftTab[eLeftExploreTexture2s].selected  = (preGestureState & 4) != 0;
			leftTab[eLeftExploreTabPosition].selected = (preGestureState & 8) != 0;
			
			[self setRandomIconState];
			[self reappearDiceTabsWithStagger:0.08f delay:0.0f];
		}
		else {	// select
			// ____ store random icon state
			preGestureState = 0;
			if (leftTab[eLeftExploreTabColors  ].selected)	preGestureState |= 1;
			if (leftTab[eLeftExploreTabLights  ].selected)	preGestureState |= 2;
			if (leftTab[eLeftExploreTexture2s ].selected)	preGestureState |= 4;
			if (leftTab[eLeftExploreTabPosition].selected)	preGestureState |= 8;
			
			leftTab[eLeftExploreTabAll].selected      = NO;
			leftTab[eLeftExploreTabColors].selected   = NO;
			leftTab[eLeftExploreTabLights].selected   = NO;
			leftTab[eLeftExploreTexture2s].selected  = NO;
			leftTab[eLeftExploreTabPosition].selected = NO;
			
			[self setRandomIconState];	// disappear the icons so they don't poke out into the screen when we disappear the tabs!!
			[self disappearDiceTabsWithStagger:0.08f];
			
			if (![fraxViewController memdotsHidden]) {
				[fraxViewController hideMemdots:YES duration:0.2f];	// flutter out memdots
				[self reappearRightTabsWithStagger:0.03f delay:0.2f];	// flutter in right tabs
				sender.selected = YES;
			}
			else {
				[self reappearRightTabsWithStagger:0.03f delay:0.0f];	// flutter in right tabs
				sender.selected = YES;
			}
		}
		/*
		if (![fraxViewController memdotsHidden]) {
			[fraxViewController hideMemdots:YES duration:0.2f];	// flutter out memdots
			[self reappearRightTabsWithStagger:0.03f delay:0.2f];	// flutter in right tabs
			sender.selected = YES;
		}
		else if (sender.selected) {
			sender.selected = NO;
			[self disappearRightTabsWithStagger:0.03f];	// flutter out right tabs
		}
		else {
			[self reappearRightTabsWithStagger:0.03f delay:0.0f];	// flutter in right tabs
			sender.selected = YES;
		}
		*/
		
		
		/*
		if (sender.selected) {	// hide gestures
			sender.selected = NO;
			[self disappearRightTabsWithStagger:0.03f];	// flutter out right tabs
			//[self minimizeLeftTabs:eLeftExploreTabGestures];
		}
		else {	// swap out gestures and memory
			leftTab[eLeftExploreTabMemory].selected = NO;
			[fraxViewController hideMemdots:YES duration:0.2f];	// flutter out memdots
			[self reappearRightTabsWithStagger:0.03f delay:0.2f];	// flutter in right tabs
			sender.selected = YES;
		}
		 */
		return;
	}
	
	if (tag == eLeftExploreTabMemory) {
		//if (sender.selected) {
		if (![fraxViewController memdotsHidden]) {
			//sender.selected = NO;
			[fraxViewController hideMemdots:YES duration:0.2f];	// flutter out memdots
			//[self minimizeLeftTabs:eLeftExploreTabMemory];
		}
		else {
			leftTab[eLeftExploreTabGestures].selected = NO;
			[self disappearRightTabsWithStagger:0.03f];	// flutter out right tabs
			[fraxViewController showMemdots:YES duration:0.2f];	// flutter in memdots
			//sender.selected = YES;
		}
	}
}

- (void)clickRightTab:(UITab*)sender {	
	int tag = sender.tag;	// 0..7
	
	NSLog(@"Explore - RightTabClicked: %d", tag);	// $$$
	
	if (tag == activeRightTab) {	// minimize / maximize right tabs
		if (rightTabsMinimized) {
			[self maximizeRightTabs];
		} else {
			[self minimizeRightTabs];
		}
		return;
	}
	
	[self setActiveRightTab:tag];
}

- (IBAction)tabTouchDown:(id)sender {
    edgeSwipe = NO;
}

- (IBAction)tabDrag:(id)sender {
	edgeSwipe = YES;
    [fraxViewController setUIHiddenState:eTabUIHidden duration:0.2f];
    [fraxViewController hideGesturesTabs];
}

- (IBAction)tabTouchUpInside:(id)sender {
	if (edgeSwipe)	return;	// don't treat a swipe as a click
	
	if (sender == diceSubTab) {
		diceSubTab.selected = YES;
		gesturesSubTab.selected = NO;
		[self reappearDiceTabsWithStagger:0.03f delay:0.0f];
		[fraxViewController hideGesturesTabs];
		
		return;
	}

	if (sender == gesturesSubTab) {
		diceSubTab.selected = NO;
		gesturesSubTab.selected = YES;
		[self disappearDiceTabsWithStagger:0.03f];
		[fraxViewController showGesturesTabs];
		return;
	}
	
    int ind;
    for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
        if (sender == leftTab[ind]) { [self clickLeftTab:sender]; return; }
    }

	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
        if (sender == rightTab[ind]) { [self clickRightTab:sender]; return; }
    }
	
	if (sender == redoTab)	{ [self clickRedo:sender]; return; }
}

- (IBAction)tabTouchUpOutside:(id)sender {
}

-(void)updateUndoRedo	// called ONLY from fraxViewController, to synchronize between explore and design rooms
{
	if (RedoAvailable() && !leftTabsMinimized)	[self redoTabReappear:redoTab];
	else										[self redoTabDisappear:redoTab];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidLoad {
	[super viewDidLoad];
	
	topSubTabView.hidden = YES;
	
	leftTab[0] = leftTab0;
	leftTab[1] = leftTab1;
	leftTab[2] = leftTab2;
	leftTab[3] = leftTab3;
	leftTab[4] = leftTab4;
	leftTab[5] = leftTab5;
	leftTab[6] = leftTab6;
	leftTab[7] = leftTab7;
	
	rightTab[0] = rightTab0;
	rightTab[1] = rightTab1;
	rightTab[2] = rightTab2;
	rightTab[3] = rightTab3;
	rightTab[4] = rightTab4;
	rightTab[5] = rightTab5;
	rightTab[6] = rightTab6;
	rightTab[7] = rightTab7;
		
	diceTab[0] = diceTabPresets;
	diceTab[1] = diceTabCurrent;
	diceTab[2] = diceTabRandom;
	
	leftTabsMinimized = false;
	rightTabsMinimized = false;
		
	redoTab.selected = false;
	redoTabDisappeared = NO; [self redoTabDisappear:redoTab];	// start with redo tab disappeared
	
	// ____ set up expand arrows on left and right tabs
	{
		UIImage* expandIm = [UIImage imageNamed:@"sidetabexpand.png"];
		CGPoint lpos = CGPointMake(25, 4);
		CGPoint rpos = CGPointMake(35, 4);
		int ind;
		for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
			[leftTab[ind] setExpandImage:expandIm position:lpos];
		}
		for (ind = 0; ind < eNumRightExploreTabs; ind++) {
			[rightTab[ind] setExpandImage:expandIm position:rpos];
		}
	}
	
#if 0	// no longer adding tiny dice
	
	UIImageView* diceView[7];
	diceView[0] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dice1.png"]];
	diceView[1] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dice2.png"]];
	diceView[2] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dice3.png"]];
	diceView[3] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dice4.png"]];
	diceView[4] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dice5.png"]];
	diceView[5] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dice6.png"]];
	diceView[6] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dice7.png"]];
	
	int ind;
	for (ind = 0; ind < 7; ind++) {
		CGRect frame = diceView[ind].frame;
		frame.origin.x += 22.0f;
		frame.origin.y -= 3.0f;
		diceView[ind].frame = frame;
		[leftTab[ind]   addSubview:diceView[ind]];
	}
	
#endif
	
	CGPoint leftDisappearOffset = CGPointMake(-leftTab[0].frame.size.width, 0.0f);
	CGPoint rightDisappearOffset = CGPointMake(rightTab[0].frame.size.width, 0.0f);
	CGPoint bottomDisappearOffset = CGPointMake(0, diceTabRandom.frame.size.height);
	
	int ind;
	for (ind = 0; ind < eNumLeftExploreTabs; ind++) {
		leftTab[ind].disappearOffset = leftDisappearOffset;
		leftTab[ind].selected = NO;
	}
	for (ind = 0; ind < eNumRightExploreTabs; ind++) {
		rightTab[ind].disappearOffset = rightDisappearOffset;
		rightTab[ind].selected = NO;
	}
	
	{
		diceIcon[0][0] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"diceiconrandom0.png"]];
		diceIcon[1][0] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"diceiconrandom1.png"]];
		diceIcon[2][0] = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"diceiconrandom2.png"]];
		
		for (ind = 0; ind < 3; ind++) {
			
			
			// $$$$$$$$ regular dice should be added here!!!!!!!!
			diceIcon[ind][1]   = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"diceiconcolors.png"  ]];
			diceIcon[ind][2]   = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"diceiconlights.png"  ]];
			diceIcon[ind][3]   = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"diceicontextures.png"]];
			diceIcon[ind][4]   = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"diceiconplaces.png"  ]];
			
			CGRect frame = diceIcon[ind][1].frame;
			
			frame.origin.y = 0.0f;
			frame.origin.x = 20.0f;		diceIcon[ind][0].frame = frame;
			frame.origin.x = 30.0f;		diceIcon[ind][1].frame = frame;
			frame.origin.x = 40.0f;		diceIcon[ind][2].frame = frame;
			frame.origin.x = 50.0f;		diceIcon[ind][3].frame = frame;
			frame.origin.x = 60.0f;		diceIcon[ind][4].frame = frame;
			
			diceTab[ind].disappearOffset = bottomDisappearOffset;
			
			// ____ add sub-icons
			[diceTab[ind] addSubview:diceIcon[ind][0]];
			[diceTab[ind] addSubview:diceIcon[ind][1]];
			[diceTab[ind] addSubview:diceIcon[ind][2]];
			[diceTab[ind] addSubview:diceIcon[ind][3]];
			[diceTab[ind] addSubview:diceIcon[ind][4]];
		}
	}
	
	//activeLeftTab = 0;	// select ALL (top left tab) by default
	activeRightTab = -1;
	leftTab[0].selected = YES;
	//randomIconState = 0;
	[self setRandomIconState];
	
	[self minimizeLeftTabs:eLeftExploreTabAll];	// minimize to tab 0
	[self disappearRightTabsWithStagger:0.0f];	// disappear Gesture tabs immediately
	[self disappear]; // $$$ start disappeared??
	
	self.lastLeftTabClick = [NSDate dateWithTimeIntervalSinceNow:-1.0f];	// one second ago
	 
	//noobButtonView.hidden = YES;	// hide huge NOOB buttons
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}



@end

