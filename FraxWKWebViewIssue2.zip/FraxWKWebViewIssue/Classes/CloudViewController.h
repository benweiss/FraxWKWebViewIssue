// *********************************************************************************************************************
// CloudViewController.h
//
// Copyright ©2011-2021 by Ben Weiss, Iter9 LLC
//
// Version: 1.1 - June 1st, 2013
// *********************************************************************************************************************

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "FraxAppDelegate.h"

@interface CloudViewController : UIViewController <WKUIDelegate, WKNavigationDelegate, WKURLSchemeHandler> {
  IBOutlet UIImageView* backdropView;
  IBOutlet WKWebView* webView;
  IBOutlet UIButton* closeButton;
}

- (void)showSavePage;
- (void)showHiResUpgrade;
- (IBAction)closeButtonClicked:(id)sender;

@property (nonatomic) UIImageView* backdropView;
@property (nonatomic) WKWebView* webView;
@property (nonatomic) UIButton* closeButton;

@end
